package com.rental;

import com.rental.dto.Customer;
import com.rental.dto.RequestedVehicle;
import com.rental.dto.ReservationRequest;
import com.rental.service.AvailabilityService;
import com.rental.service.ReservationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AppTests {

    @Test
    public void contextLoads() {
    }

    @Test
    public void testAvailabilityService() {
        // assuming there are 10 of SUV in the system
        ReservationRequest reservationRequest = new ReservationRequest();
        Customer c = new Customer("Christina", "Huynh", "2000-01-01");
        RequestedVehicle v = new RequestedVehicle();
        v.setVehicleType("SUV");
        v.setFromDate("2020-11-04");
        v.setFromTime("06:00:00");
        v.setNoOfDays("5");
        reservationRequest.setCustomer(c);
        reservationRequest.setRequestedVehicle(v);

        assertTrue(AvailabilityService.isAvailable(reservationRequest.getRequestedVehicle()));
    }

}
