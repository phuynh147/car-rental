package com.rental.model.vehicle;

public interface Vehicle<T extends Enum<AvailableVehicleType>> {

	public T getVehicleType();

}
