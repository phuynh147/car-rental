package com.rental.model.vehicle.car;

import com.rental.model.vehicle.AvailableVehicleType;
import com.rental.model.vehicle.Vehicle;

public class Car implements Vehicle<AvailableVehicleType> {

    /**
     * {@inheritDoc}}
     */
    @Override
    public AvailableVehicleType getVehicleType() {
        return AvailableVehicleType.CAR;
    }
}
