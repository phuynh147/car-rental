package com.rental.model.vehicle;

import java.util.List;

public interface RentalVehicle<T extends Vehicle<AvailableVehicleType>> {
	
	public T getVehicle();
	
	public List<VehicleSubType<T>> getVehicleSubType();

}
