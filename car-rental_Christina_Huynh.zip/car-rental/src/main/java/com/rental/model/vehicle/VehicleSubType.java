package com.rental.model.vehicle;

public interface VehicleSubType<T extends Vehicle<AvailableVehicleType>> {
	
	public String getSubTypeName();
	
	public int getSubTypeVolume();

}
