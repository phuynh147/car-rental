package com.rental.model.vehicle.car.subtype;

import com.rental.constants.Constants;
import com.rental.model.vehicle.VehicleSubType;
import com.rental.model.vehicle.car.Car;

public class Suv implements VehicleSubType<Car>{

	@Override
	public String getSubTypeName() {
		return Constants.SUV;
	}

	@Override
	public int getSubTypeVolume() {
		return Constants.SUV_VOLUME;
	}

}
