package com.rental.model.vehicle.car.subtype;

import com.rental.constants.Constants;
import com.rental.model.vehicle.VehicleSubType;
import com.rental.model.vehicle.car.Car;

public class Sedan implements VehicleSubType<Car>{

	@Override
	public String getSubTypeName() {
		return Constants.SEDAN;
	}

	@Override
	public int getSubTypeVolume() {
		return Constants.SEDAN_VOLUME;
	}

}
