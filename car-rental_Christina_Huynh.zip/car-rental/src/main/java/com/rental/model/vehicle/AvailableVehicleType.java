package com.rental.model.vehicle;

public enum AvailableVehicleType {	
	CAR
}
