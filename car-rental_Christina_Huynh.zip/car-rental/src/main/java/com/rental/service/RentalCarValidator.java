package com.rental.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rental.constants.Constants;
import com.rental.dto.Customer;
import com.rental.dto.RequestedVehicle;
import com.rental.dto.ReservationRequest;
import com.rental.dto.ResponseMessage;
import org.springframework.util.StringUtils;

public class RentalCarValidator {

    public static ResponseMessage validateInputCarDetails(ReservationRequest request) {

        Customer customer = request.getCustomer();
        //validate first name
        if (StringUtils.isEmpty(customer.getFirstName())) {
            return getResponseMessage(true, Constants.REQUIRED_FIRST_NAME, null);
        }

        //validate last name
        if (StringUtils.isEmpty(customer.getLastName())) {
            return getResponseMessage(true, Constants.REQUIRED_LAST_NAME, null);
        }

        //validate date of birth
        if (StringUtils.isEmpty(customer.getDateOfBirth())) {
            return getResponseMessage(true, Constants.REQUIRED_DOB, null);
        }

        if (!isDateValid(customer.getDateOfBirth(), Constants.DATE_FORMAT)) {
            return getResponseMessage(true, Constants.INCORRECT_DOB, null);
        }

        RequestedVehicle vehicleToBook = request.getRequestedVehicle();

        //validate vehicle Type
        if (!(Constants.SEDAN.equalsIgnoreCase(vehicleToBook.getVehicleType()) ||
                Constants.SUV.equalsIgnoreCase(vehicleToBook.getVehicleType()) ||
                Constants.VAN.equalsIgnoreCase(vehicleToBook.getVehicleType()))) {
            return getResponseMessage(true, String.format(Constants.INVALID_VEHICLE_TYPE, vehicleToBook.getVehicleType()), null);
        }

        //validate from date
        if (!isDateValid(vehicleToBook.getFromDate(), Constants.DATE_FORMAT)) {
            return getResponseMessage(true, Constants.INVALID_VEHICLE_REGISTER_FROM_DATE, null);
        }

        //validate from time
        if (!isValidTime(vehicleToBook.getFromTime(), Constants.TIME24HOURS_PATTERN)) {
            return getResponseMessage(true, String.format(Constants.INVALID_VEHICLE_REGISTER_FROM_TIME, vehicleToBook.getFromTime()), null);
        }

        // validate date time is greater than current time
        if (!isFromDateTimeValid(vehicleToBook.getFromDate(), vehicleToBook.getFromTime())) {
            return getResponseMessage(true, String.format(Constants.INVALID_BOOKING_DATE_TIME, vehicleToBook.getFromDate(), vehicleToBook.getFromTime()), null);
        }

        if (!AvailabilityService.isAvailable(vehicleToBook)) {
            return getResponseMessage(true, String.format(Constants.NOT_AVAILABLE), null);
        }

        return getResponseMessage(false, null, request.getRequestedVehicle());
    }

    public static ResponseMessage getResponseMessage(boolean isError, String errorMessage, Object data) {
        ResponseMessage respMsg = new ResponseMessage();
        respMsg.setError(isError);
        respMsg.setErrorMessage(errorMessage);
        respMsg.setData(data);
        return respMsg;
    }


    public static boolean isValidTime(String timeToValidate, String timePattern) {
        Pattern pattern = Pattern.compile(timePattern);
        Matcher matcher = pattern.matcher(timeToValidate);
        return matcher.matches();
    }

    public static boolean isFromDateTimeValid(String dateToValidate, String timeStr) {
        if (dateToValidate == null) {
            return false;
        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT);
        try {
            String dateStr = dateToValidate.concat(" ").concat(timeStr);
            LocalDateTime enteredDateTime = LocalDateTime.parse(dateStr, dtf);
            LocalDateTime now = LocalDateTime.now();
            if (enteredDateTime.isBefore(now)) {
                return false;
            }
        } catch (DateTimeParseException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static boolean isDateValid(String dateToValidate, String dateFromat) {

        if (dateToValidate == null) {
            return false;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
        sdf.setLenient(false);

        Date date = null;
        try {
            date = sdf.parse(dateToValidate);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }

}
