package com.rental.service;

import com.rental.dto.RequestedVehicle;
import com.rental.dto.VehicleDetail;

import java.util.List;

public class AvailabilityService {

    public static boolean isAvailable(RequestedVehicle request) {

        request.getVehicleType();
        List<VehicleDetail> availableCars = ReservationService.getAvailableCars();
        int availability = 0;
        for (VehicleDetail vehicleDetail : availableCars) {
            if (vehicleDetail.getSubType().equalsIgnoreCase(request.getVehicleType())) {
                availability = vehicleDetail.getAvailableQty();
            }
        }

        if (availability == 0) {
            return false;
        }

        return true;
    }
}
