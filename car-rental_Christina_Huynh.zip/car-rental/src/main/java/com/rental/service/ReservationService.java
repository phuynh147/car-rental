package com.rental.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import com.rental.dto.RequestedVehicle;
import com.rental.dto.ReservationDetail;
import com.rental.constants.Constants;
import com.rental.dto.Customer;
import com.rental.dto.VehicleDetail;
import com.rental.model.vehicle.AvailableVehicleType;
import com.rental.model.vehicle.car.subtype.Sedan;
import com.rental.model.vehicle.car.subtype.Suv;
import com.rental.model.vehicle.car.subtype.Van;

public class ReservationService {

    private static List<ReservationDetail> reservedVehicleDetailList = new ArrayList<>();

    /**
     * @param reservationNumber
     * @return
     */
    public static List<ReservationDetail> getReservationByReferenceNumber(String reservationNumber) {
        if (reservationNumber == null) {
            return Collections.emptyList();
        }
        List<ReservationDetail> bookingDetail = Collections.emptyList();
        synchronized (reservedVehicleDetailList) {
            bookingDetail = reservedVehicleDetailList.stream().filter(p -> reservationNumber.equalsIgnoreCase(p.getReservationNumber())).collect(Collectors.toList());
        }
        return bookingDetail;
    }

    /**
     * @param customer
     * @param vehicleToBook
     * @return
     */
    public static String reserveCar(Customer customer, RequestedVehicle vehicleToBook) {
        LocalDateTime fromDateTime = getDateTime(vehicleToBook.getFromDate(), vehicleToBook.getFromTime());
        LocalDateTime toDateTime = fromDateTime.plusDays(Long.parseLong(vehicleToBook.getNoOfDays()));

        if (null == fromDateTime || null == toDateTime) {
            return null;
        }

        String reservationNumber = UUID.randomUUID().toString();

        ReservationDetail reservationDetail = new ReservationDetail(customer, AvailableVehicleType.CAR.toString(), vehicleToBook.getVehicleType(), fromDateTime, toDateTime, reservationNumber);
        synchronized (reservedVehicleDetailList) {
            reservedVehicleDetailList.add(reservationDetail);
        }
        return reservationNumber;
    }

    /**
     * @param dateStr
     * @param timeStr
     * @return
     */
    public static LocalDateTime getDateTime(String dateStr, String timeStr) {
        if (null == dateStr || null == timeStr) {
            return null;
        }
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT);
        LocalDateTime localDateTime = null;
        String dateTimeStr = null;
        try {
            dateTimeStr = dateStr.concat(" ").concat(timeStr);
            localDateTime = LocalDateTime.parse(dateTimeStr, dtf);

        } catch (DateTimeParseException e) {
            System.out.println("Error in parsing date.[" + dateTimeStr + "]");
    }
        return localDateTime;
    }

    /**
     * @return
     */
    public static List<VehicleDetail> getAvailableCars() {

        List<VehicleDetail> vehicleDetails = new ArrayList<VehicleDetail>();
        int bookedSedanNumber = 0;
        int bookedSuvNumber = 0;
        int bookedVanNumber = 0;

        int availableSedanNumber = 0;
        int availableSuvNumber = 0;
        int availableVanNumber = 0;

        Sedan sedan = new Sedan();
        Suv suv = new Suv();
        Van van = new Van();

        String vehicleType = AvailableVehicleType.CAR.toString();

        synchronized (reservedVehicleDetailList) {
            bookedSedanNumber = reservedVehicleDetailList.stream()
                    .filter(p -> Constants.SEDAN.equalsIgnoreCase(p.getVehicleSubType())
                            && AvailableVehicleType.CAR.toString().equalsIgnoreCase(p.getVehicleType()))
                    .collect(Collectors.toList()).size();

            availableSedanNumber = sedan.getSubTypeVolume() - bookedSedanNumber;

            bookedSuvNumber = reservedVehicleDetailList.stream()
                    .filter(p -> Constants.SUV.equalsIgnoreCase(p.getVehicleSubType())
                            && AvailableVehicleType.CAR.toString().equalsIgnoreCase(p.getVehicleType()))
                    .collect(Collectors.toList()).size();

            availableSuvNumber = suv.getSubTypeVolume() - bookedSuvNumber;

            bookedVanNumber = reservedVehicleDetailList.stream()
                    .filter(p -> Constants.VAN.equalsIgnoreCase(p.getVehicleSubType())
                            && AvailableVehicleType.CAR.toString().equalsIgnoreCase(p.getVehicleType()))
                    .collect(Collectors.toList()).size();
            availableVanNumber = van.getSubTypeVolume() - bookedVanNumber;
        }

        VehicleDetail sedanDetail = new VehicleDetail(vehicleType, Constants.SEDAN, availableSedanNumber);
        VehicleDetail suvDetail = new VehicleDetail(vehicleType, Constants.SUV, availableSuvNumber);
        VehicleDetail vanDetail = new VehicleDetail(vehicleType, Constants.VAN, availableVanNumber);

        vehicleDetails.add(sedanDetail);
        vehicleDetails.add(suvDetail);
        vehicleDetails.add(vanDetail);

        return vehicleDetails;
    }

}
