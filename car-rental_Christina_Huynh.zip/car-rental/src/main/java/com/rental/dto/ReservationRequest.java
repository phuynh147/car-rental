package com.rental.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ReservationRequest {

	@JsonProperty("customer")
	private Customer customer;

	@JsonProperty("vehicle")
	private RequestedVehicle RequestedVehicle;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public RequestedVehicle getRequestedVehicle() {
		return RequestedVehicle;
	}

	public void setRequestedVehicle(RequestedVehicle RequestedVehicle) {
		this.RequestedVehicle = RequestedVehicle;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ReservationRequest [customer=");
		builder.append(customer);
		builder.append(", RequestedVehicle=");
		builder.append(RequestedVehicle);
		builder.append("]");
		return builder.toString();
	}
	
}
