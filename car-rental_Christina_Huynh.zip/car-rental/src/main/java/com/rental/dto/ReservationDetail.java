package com.rental.dto;

import java.time.LocalDateTime;

public class ReservationDetail {
	
	private Customer customer;
	private String vehicleType;
	private String vehicleSubType;
	private LocalDateTime startDateTime;
	private LocalDateTime endDateTime;
	private String reservationNumber;
	
	public ReservationDetail(Customer customer,String vehicleType, String vehicleSubType, LocalDateTime startDateTime,
			LocalDateTime endDateTime, String reservationNumber) {
		this.customer = customer;
		this.vehicleType = vehicleType;
		this.vehicleSubType = vehicleSubType;
		this.startDateTime = startDateTime;
		this.endDateTime = endDateTime;
		this.reservationNumber = reservationNumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getVehicleSubType() {
		return vehicleSubType;
	}

	public void setVehicleSubType(String vehicleSubType) {
		this.vehicleSubType = vehicleSubType;
	}

	public LocalDateTime getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(LocalDateTime startDateTime) {
		this.startDateTime = startDateTime;
	}

	public LocalDateTime getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(LocalDateTime endDateTime) {
		this.endDateTime = endDateTime;
	}

	public String getReservationNumber() {
		return reservationNumber;
	}

	public void setReservationNumber(String reservationNumber) {
		this.reservationNumber = reservationNumber;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ReservationDetail [customer=");
		builder.append(customer);
		builder.append(", vehicleType=");
		builder.append(vehicleType);
		builder.append(", vehicleSubType=");
		builder.append(vehicleSubType);
		builder.append(", startDateTime=");
		builder.append(startDateTime);
		builder.append(", endDateTime=");
		builder.append(endDateTime);
		builder.append(", reservationNumber=");
		builder.append(reservationNumber);
		builder.append("]");
		return builder.toString();
	}
	
}
