package com.rental.controller;

import java.util.List;

import com.rental.dto.*;
import com.rental.service.RentalCarValidator;
import com.rental.service.ReservationService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReservationController {

    /**
     * @return
     */
    @RequestMapping(value = "/getAvailableCars", method = RequestMethod.GET, produces = {"application/json"})
    public List<VehicleDetail> getAvailableCars() {
        return ReservationService.getAvailableCars();
    }

    /**
     * @param request
     * @return
     */
    @RequestMapping(value = "/reserve", method = RequestMethod.POST, consumes = {"application/json"}, produces = {"application/json"})
    public ResponseMessage reserveCar(@RequestBody ReservationRequest request) {
        ResponseMessage respMessage = RentalCarValidator.validateInputCarDetails(request);
        if (!respMessage.isError()) {
            RequestedVehicle vehicle = request.getRequestedVehicle();
            String referenceNumber = ReservationService.reserveCar(request.getCustomer(), vehicle);
            if (null == referenceNumber) {
                vehicle.setReferenceNumber("NULL");
            } else {
                vehicle.setReferenceNumber(referenceNumber);
            }
            respMessage.setData(request.getRequestedVehicle());
        }

        return respMessage;
    }

    /**
     * @param reservationNumber
     * @return
     */
    @RequestMapping(value = "/getReservationDetail", method = RequestMethod.POST, produces = {"application/json"})
    public Object getReservationDetail(@RequestHeader("reservationNumber") String reservationNumber) {
        return ReservationService.getReservationByReferenceNumber(reservationNumber);
    }

}
